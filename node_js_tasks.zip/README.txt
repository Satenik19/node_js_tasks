1. npm install
2. for the calculator task -> node task-1.js
3. for the unzipper task -> node task-2.js